package com.example.studyflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Today
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudyFlowApp() }
    }
}

data class StudyTask(
    val id: String = UUID.randomUUID().toString(),
    val date: String,
    val start: String,
    val end: String,
    val title: String,
    val category: String,
    val checked: Boolean = false,
    val note: String = ""
)

private val categories = listOf("GenieX", "机器学习", "CSP", "考研", "邮件系统", "运动", "课程", "休息", "其他")
private val categoryColors = mapOf(
    "GenieX" to Color(0xFF547FAE), "机器学习" to Color(0xFF8C72C6), "CSP" to Color(0xFF4C9B77),
    "考研" to Color(0xFFC58A43), "邮件系统" to Color(0xFF4F9BA5), "运动" to Color(0xFFCB6F75),
    "课程" to Color(0xFF77818E), "休息" to Color(0xFF8C969F), "其他" to Color(0xFF777777)
)

@Composable
fun StudyFlowApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("studyflow", 0) }
    var tasks by remember { mutableStateOf(loadTasks(prefs)) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<StudyTask?>(null) }

    fun save(newTasks: List<StudyTask>) {
        tasks = newTasks
        prefs.edit().putString("tasks", JSONArray().apply {
            newTasks.forEach { t -> put(JSONObject().apply {
                put("id", t.id); put("date", t.date); put("start", t.start); put("end", t.end)
                put("title", t.title); put("category", t.category); put("checked", t.checked); put("note", t.note)
            }) }
        }.toString()).apply()
    }

    val dateKey = selectedDate.toString()
    val daily = tasks.filter { it.date == dateKey }.sortedBy { it.start }
    val done = daily.count { it.checked }
    val progress = if (daily.isEmpty()) 0f else done.toFloat() / daily.size

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF477B9D), secondary = Color(0xFF5B927D), background = Color(0xFFF6F7F9))) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Today, null) }, label = { Text("计划") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Insights, null) }, label = { Text("统计") })
                }
            },
            floatingActionButton = { if (tab == 0) FloatingActionButton(onClick = { editing = null; showAdd = true }) { Icon(Icons.Default.Add, "添加任务") } }
        ) { padding ->
            if (tab == 0) DailyScreen(selectedDate, daily, done, progress, padding,
                onPrevious = { selectedDate = selectedDate.minusDays(1) },
                onNext = { selectedDate = selectedDate.plusDays(1) },
                onToday = { selectedDate = LocalDate.now() },
                onToggle = { task -> save(tasks.map { if (it.id == task.id) it.copy(checked = !it.checked) else it }) },
                onEdit = { editing = it; showAdd = true },
                onDelete = { task -> save(tasks.filterNot { it.id == task.id }) }
            ) else StatisticsScreen(tasks, padding)
        }

        if (showAdd) TaskDialog(
            initial = editing,
            date = selectedDate,
            onDismiss = { showAdd = false },
            onSave = { task ->
                val updated = if (editing == null) tasks + task else tasks.map { if (it.id == task.id) task else it }
                save(updated); showAdd = false
            }
        )
    }
}

@Composable
fun DailyScreen(date: LocalDate, tasks: List<StudyTask>, done: Int, progress: Float, padding: PaddingValues,
                onPrevious: () -> Unit, onNext: () -> Unit, onToday: () -> Unit,
                onToggle: (StudyTask) -> Unit, onEdit: (StudyTask) -> Unit, onDelete: (StudyTask) -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(16.dp))
        Text("StudyFlow", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("把计划变成每天完成的行动", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Card(shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    IconButton(onClick = onPrevious) { Icon(Icons.Default.ArrowBack, "前一天") }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(date.format(DateTimeFormatter.ofPattern("MM月dd日")), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(date.format(DateTimeFormatter.ofPattern("EEEE")), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onNext) { Icon(Icons.Default.ArrowForward, "后一天") }
                }
                TextButton(onClick = onToday, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("回到今天") }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("完成 $done/${tasks.size}", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text("${(progress * 100).toInt()}%", color = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), trackColor = MaterialTheme.colorScheme.surfaceVariant)
            }
        }
        Spacer(Modifier.height(14.dp))
        if (tasks.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("今天还没有计划，点击 + 添加任务", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            LazyColumn(contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tasks, key = { it.id }) { task ->
                    TaskCard(task, onToggle = { onToggle(task) }, onEdit = { onEdit(task) }, onDelete = { onDelete(task) })
                }
            }
        }
    }
}

@Composable
fun TaskCard(task: StudyTask, onToggle: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val color = categoryColors[task.category] ?: Color.Gray
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = if (task.checked) Color(0xFFF0F3F3) else MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = task.checked, onCheckedChange = { onToggle() })
            Column(Modifier.weight(1f).padding(start = 4.dp)) {
                Text("${task.start}—${task.end}", style = MaterialTheme.typography.labelMedium, color = color, fontWeight = FontWeight.Bold)
                Text(task.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                    color = if (task.checked) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).background(color, RoundedCornerShape(50)))
                    Spacer(Modifier.width(6.dp))
                    Text(task.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (task.note.isNotBlank()) Text(task.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onEdit) { Icon(Icons.Default.CalendarMonth, "编辑") }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "删除", tint = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
fun TaskDialog(initial: StudyTask?, date: LocalDate, onDismiss: () -> Unit, onSave: (StudyTask) -> Unit) {
    var title by remember(initial) { mutableStateOf(initial?.title ?: "") }
    var start by remember(initial) { mutableStateOf(initial?.start ?: "09:00") }
    var end by remember(initial) { mutableStateOf(initial?.end ?: "10:00") }
    var category by remember(initial) { mutableStateOf(initial?.category ?: "GenieX") }
    var note by remember(initial) { mutableStateOf(initial?.note ?: "") }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "添加任务" else "编辑任务") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("任务名称") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(start, { start = it }, label = { Text("开始时间") }, modifier = Modifier.weight(1f), singleLine = true)
                    OutlinedTextField(end, { end = it }, label = { Text("结束时间") }, modifier = Modifier.weight(1f), singleLine = true)
                }
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(category, {}, readOnly = true, label = { Text("分类") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { category = option; expanded = false }) }
                    }
                }
                OutlinedTextField(note, { note = it }, label = { Text("备注（可选）") }, minLines = 2)
            }
        },
        confirmButton = { Button(onClick = { if (title.isNotBlank()) onSave(StudyTask(id = initial?.id ?: UUID.randomUUID().toString(), date = date.toString(), start = start, end = end, title = title, category = category, checked = initial?.checked ?: false, note = note)) }) { Text("保存") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

@Composable
fun StatisticsScreen(tasks: List<StudyTask>, padding: PaddingValues) {
    val today = LocalDate.now()
    val weekStart = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val weekTasks = tasks.filter { runCatching { LocalDate.parse(it.date).let { d -> !d.isBefore(weekStart) && !d.isAfter(today) } }.getOrDefault(false) }
    val finished = weekTasks.count { it.checked }
    val byCategory = weekTasks.groupBy { it.category }
    Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
        Text("学习统计", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("本周（${weekStart.format(DateTimeFormatter.ofPattern("MM/dd"))}—${today.format(DateTimeFormatter.ofPattern("MM/dd"))}）", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("计划任务", weekTasks.size.toString(), Modifier.weight(1f))
            StatCard("已完成", finished.toString(), Modifier.weight(1f))
            StatCard("完成率", if (weekTasks.isEmpty()) "0%" else "${finished * 100 / weekTasks.size}%", Modifier.weight(1f))
        }
        Spacer(Modifier.height(20.dp))
        Text("各项目完成情况", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (byCategory.isEmpty()) Text("本周还没有记录。")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(byCategory.entries.toList()) { entry ->
                val total = entry.value.size; val complete = entry.value.count { it.checked }
                Card { Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row { Text(entry.key, fontWeight = FontWeight.SemiBold); Spacer(Modifier.weight(1f)); Text("$complete/$total") }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(progress = { if (total == 0) 0f else complete.toFloat()/total }, modifier = Modifier.fillMaxWidth())
                } }
            }
        }
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } }
}

fun loadTasks(prefs: android.content.SharedPreferences): List<StudyTask> {
    val raw = prefs.getString("tasks", null) ?: return emptyList()
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i -> arr.getJSONObject(i).let { o ->
            StudyTask(id = o.optString("id"), date = o.optString("date"), start = o.optString("start"), end = o.optString("end"),
                title = o.optString("title"), category = o.optString("category", "其他"), checked = o.optBoolean("checked"), note = o.optString("note"))
        } }
    } catch (_: Exception) { emptyList() }
}
